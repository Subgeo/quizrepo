var searchData=
[
  ['college',['College',['../classCollege.html#adabaf4087355e83f9f7d39f1e1498b41',1,'College']]]
];
